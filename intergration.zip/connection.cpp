#include "connection.h"

Connection::Connection()
{

}

bool Connection::createconnect()
{bool test=false;
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("testt");//nom de la base
db.setUserName("lina");//inserer nom de l'utilisateur
db.setPassword("lina");//inserer mot de passe de cet utilisateur

if (db.open())
test=true;
    return  test;
}
